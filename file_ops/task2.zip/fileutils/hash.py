# coding=UTF-8
import hashlib
from pathlib import Path


def generate_md5_for_file(file_path):
    """

    :param str or Path file_path: Melyik fájlból generáljon md5-t
    :return str: Generált md5
    """
    pass  # TODO


def generate_md5_file_for_file(file_path, md5_file_path):
    """

    :param str or Path file_path: Melyik fájlból generáljon md5-t
    :param str or Path md5_file_path: Generált md5 fájl elérési útja
    :return:
    """
    pass  # TODO


if __name__ == '__main__':
    import argparse
    pass  # TODO CLI készítés
